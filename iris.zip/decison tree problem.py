import numpy as np

def entropy(x, y):
    # Combine x and y into a 2D array
    data = np.column_stack((x, y))

    # Calculate the total number of data points
    total_samples = len(data)

    # Calculate the number of samples for each class
    count_class_0 = np.sum(y == 0)
    count_class_1 = np.sum(y == 1)

    # Calculate the proportions of each class
    p_class_0 = count_class_0 / total_samples
    p_class_1 = count_class_1 / total_samples

    # Avoid division by zero in case one of the classes has no samples
    if p_class_0 == 0 or p_class_1 == 0:
        entropy = 0
    else:
        # Calculate entropy using the formula
        entropy = -p_class_0 * np.log2(p_class_0) - p_class_1 * np.log2(p_class_1)

    return entropy
def gain(x, y, f):
    # Combine x, y, and feature f into a 2D array
    data = np.column_stack((x, y, f))

    # Calculate the entropy of the parent set
    entropy_parent = entropy(x, y)

    # Get unique values of the feature f
    unique_values = np.unique(f)

    # Calculate the information gain
    information_gain = entropy_parent
    for value in unique_values:
        subset = data[data[:, 2] == value]
        entropy_subset = entropy(subset[:, 0], subset[:, 1])
        information_gain -= (len(subset) / len(data)) * entropy_subset

    return information_gain
def decision_tree(x,y,features,level):
    if(len(features)==0):
       return
     #checking if all the features are exhausted
    if(set(y)==1):
        return
    zeros=(y==0)
    ones=(y==1)
    print("Level"+level+"\n")
    print("Count of 0(zero)"+zeros)
    print("Count of 0(zero)"+ones)
    print("Entropy of the state"+entropy(x,y))
     # if pure node than return
    max=0
    #calculating thefeature on which split is being performed
    for f in features:
        info_gain=gain(x,y,f)
        if(info_gain>max):
            max=info_gain
            feature_to_split=f
    print("Splitting on feature "+f+" with information gain of "+max)
    features = [item for item in features if item != f]
    #removing f from features
    for i in f:
        x_train= (x[f] == i)
        # Filter data using the particular feature label in selected feature
        y_train = y[x_train]
        decision_tree(x_train,y_train,features,level+1)

